# SU_Portefoelje2024
Porteføljeeksamen til Softwareudvikling, på 2. semester (2024) - af Lucas Rosenkvist Rasmussen


GUIDE
______________________________
For at kunne spille spillet er følgende nødvendigt:

1. Åbn og log på MYSQL localhost på den PC du ønsker at køre spillet på.
2. Kopier og indsæt teksten fra DBInit.txt filen.
3. Kør executable
4. Du præsenteres med en meddelelse om at indtaste login for den MYSQL localhost bruger du netop har oprettet databasen i. Her er det vigtigt at du er sikker på det er de rigtige oplysninger du indtaster, for at programmet kan kommunikere med databasen.

Så er der ikke andet for end at nyde spillet og have det sjovt!
